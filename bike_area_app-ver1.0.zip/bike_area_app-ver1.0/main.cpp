#include <iostream>

using namespace std;
int main() {
  cout << "Let's チャリ徹" << endl;
  return 0;
}
