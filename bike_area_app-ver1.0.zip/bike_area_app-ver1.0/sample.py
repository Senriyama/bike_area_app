print('Hello')
print('hi')